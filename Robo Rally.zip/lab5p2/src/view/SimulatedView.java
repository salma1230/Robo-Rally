package view;

import model.Field;


public interface SimulatedView {
public abstract void registerClass(Class actorclass);
public abstract void showStatus(int step, Field field);



}
