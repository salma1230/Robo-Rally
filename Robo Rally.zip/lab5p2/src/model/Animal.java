package model;

import java.util.List;

/**
 * A simple model of an animal.
 * 
 * @author Ian T. Nabney
 * @version 02-02-2005
 */
public abstract class Animal implements Actor
{
	// The animal's age.
	private int age;
	// Whether the animal is alive or not.
	protected boolean alive;
	// The animal's position
	protected Location location;
	
	
	/**
	 * Create an animal. An animal is created as a new born (age zero).
	 */
	public Animal()
	{
		age = 0;
		alive = true;
	}
	
	/**
	 * This is what animals do.
	 */
	public abstract void act(Field currentField, Field updatedField, 
			List<Actor> newAnimals);
	
	/**
	 * These methods must be defined in concrete subclasses
	 */
	public abstract int getBreedingAge();
	public abstract int getMaxAge();
	
	/**
	 * Increase the age. This could result in the animal's death.
	 */
	protected void incrementAge()
	{
		age++;
		if(age > getMaxAge()) {
			alive = false;
		}
	}
	
	/**
	 * Accessor method for age.
	 */
	public int getAge() {
		return age;
	}
	
	/**
	 * Mutator method for age.
	 */
	public void setAge(int age) {
		this.age = age;
	}
	
	/**
	 * An animal can breed if it has reached the breeding age.
	 */
	protected boolean canBreed()
	{
		return age >= getBreedingAge();
	}
	
	
	/**
	 * Check whether the animal is alive or not.
	 * @return True if the fox is still alive.
	 */
	public boolean isAlive()
	{
		return alive;
	}
	
	/**
	 * Tell the animal it is dead.
	 */
	public void setDead() 
	{
		alive = false;
	}
	
	/**
	 * Set the animal's location.
	 * @param row The vertical coordinate of the location.
	 * @param col The horizontal coordinate of the location.
	 */
	public void setLocation(int row, int col)
	{
		this.location = new Location(row, col);
	}
	
	/**
	 * Set the animal's location.
	 * @param location The animal's location.
	 */
	public void setLocation(Location location)
	{
		this.location = location;
	}
	
}
