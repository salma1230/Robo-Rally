package model;

import java.util.List;
import java.util.Random;

/**
 * A simple model of a hunter.
 * Hunters move around shooting animals.
 * 
 * @author Ian T. Nabney
 * @version 02-02-2005
 */
public class Hunter implements Actor
{
	private Location location;
	private static final int SEED = 42;
	private static final Random rand = new Random(SEED);
	private static final double KILL_PROBABILITY = 0.4;
	
	/**
	 * Create a hunter. 
	 */
	public Hunter()
	{
	}
	
	/**
	 * This is what the hunter does most of the time.
	 */
	public void act(Field currentField, Field updatedField, List<Actor> newHunters)
	{
		// Must do something or they will disappear
		Location newLocation = updatedField.randomAdjacentLocation(location);
		this.setLocation(newLocation.getRow(), newLocation.getCol());
		updatedField.place(this, newLocation);
		Location aimingAt = updatedField.randomAdjacentLocation(newLocation);
		Actor actor = updatedField.getObjectAt(aimingAt);
		if (actor instanceof Animal) {
			// Kill it with the right probability
			if (rand.nextDouble() <= KILL_PROBABILITY) {
				((Animal)actor).setDead();
			}
		}
	}
	
	/**
	 * Hunters never die.....
	 */
	public boolean isAlive()
	{
		return true;
	}
	
	/**
	 * Set the hunter's location.
	 * @param row The vertical coordinate of the location.
	 * @param col The horizontal coordinate of the location.
	 */
	public void setLocation(int row, int col)
	{
		this.location = new Location(row, col);
	}
	
}
