package model;

import java.util.List;

/**
 * A simple model of an actor in a simulation.
 * 
 * @author Ian T. Nabney
 * @version 02-02-2005
 */
public interface Actor
{
    
    /**
     * This is what actors do.
     */
    public abstract void act(Field currentField, Field updatedField, 
			     List<Actor> newActors);
    public abstract boolean isAlive();
    public abstract void setLocation(int row, int col);
}
