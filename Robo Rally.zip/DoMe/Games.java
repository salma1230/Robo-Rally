
public class Games {
private int numPlayers; 
	
public Games(int numberOfPlayers) {
	this.numPlayers = numberOfPlayers;
	
}

public int getNumPlayers() {
	return numPlayers;
	
}

}
