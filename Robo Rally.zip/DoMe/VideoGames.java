
public class VideoGames extends Games {
private String platform;

	public VideoGames(int numberOfPlayers, String platform) {
		 super(numberOfPlayers);
		this.platform = platform;
		// TODO Auto-generated constructor stub
	}


	
public String getPlatforms() {
	
	return platform;
}

}
