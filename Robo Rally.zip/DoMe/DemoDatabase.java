/**
 * DemoDatabase provides a short demo of the DOME system.
 *
 * @author Ian T. Nabney
 * @version 16/01/2005
 */

public class DemoDatabase
{

    public static void main(String[] args) 
    {
    	Database d = new Database();
    	CD cd1 = new CD("Vivaldi concertos", "Giuliano Carmignola",
    			12, 60);
    	CD cd2 = new CD("Schubert sonata in A", "Radu Lupu",
    			4, 35);
    	Video v1 = new Video("Seven Samurai", "Akira Kurosawa", 206);
    	Video v2 = new Video("La Belle et la Bete", "Jean Cocteau", 120);
    	
	cd1.setComment("Virtuosic and imaginative fantasy");
	cd2.setComment("Warm and human, with a touch of wildness in the slow movement.");

	v1.setComment("The greatest epic of the 20th century in any art form.");
	v2.setComment("Who needs CGI when you have imagination?");

    	d.addItem(cd1);
    	d.addItem(cd2);
    	d.addItem(v1);
    	d.addItem(v2);
    	
    	d.list();
    }

}
