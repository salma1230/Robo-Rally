
public class BoardGames extends Games{

	public BoardGames(int numberOfPlayers) {
		super(numberOfPlayers);
		// TODO Auto-generated constructor stub
	}

	

}
