


public class NormalRoom extends Room {

		public NormalRoom(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

		public Room getExit(String direction) 
    {
        return (Room)exits.get(direction);
    }
	}
	

