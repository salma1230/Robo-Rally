import java.util.Random;
import java.util.ArrayList;
public class Roomset {
private ArrayList<Room>rooms;
private Random gen;


public Roomset(Random gen2){
	gen = new Random();
	gen = gen2;
	rooms = new ArrayList<Room>();	
	
}

public void addRoom(Room room){
	rooms.add(room);
	
	
}

public Room findRandomRoom(){
	int num = rooms.size();
	int index = gen.nextInt(num);
	return rooms.get(index);
	
}
}
