
public class TransporterRoom extends Room {
private Roomset rooms;
	public TransporterRoom(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public Room getExit(String direction){
		return rooms.findRandomRoom();
		
	
	}
	
	public void setRoomSet(Roomset Rooms) {
	
	
	
	
		
	}
}
