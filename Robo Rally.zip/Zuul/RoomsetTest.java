import java.util.Random;

import org.junit.Before;
import org.junit.Test;

public class RoomsetTest {
	private Room outside;
	private int outsidenum;
	private Room theatre;
	private int theatrenum;
	private Room pub;
	private int pubnum;
	private Room lab;
	private int labnum;
	private Room office;
	private int officenum;
	
public RoomsetTest(){}

	
	@Before
	public void setUp() throws Exception {
	}

	@org.junit.Test
	public void Roomset() {
		Roomset rs = new Roomset(new Random(42));
		rs.addRoom(outside);
		rs.addRoom(theatre);
		rs.addRoom(pub);
		rs.addRoom(lab);
		rs.addRoom(office);
		int i = 0;
		
		while ( i< 10000){
		Room a = rs.findRandomRoom();		

		if(a.equals(outside)){
				outsidenum++;
				i++;
			}
			if(a.equals(theatre)){
				theatrenum++;
			i++;
			}
				
			if(a.equals(pub)){
				pubnum++;
				i++;
				
			}
			if(a.equals(lab)){
				labnum++;
				i++;
				
			}
			
			if(a.equals(office)){
				officenum++;
				i++;
			}
			
			
		}
	
	}

}
