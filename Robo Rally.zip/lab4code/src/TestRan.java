/**
 * Simple class to test random number generator properties
 *
 * Copyright (c) Ian T. Nabney 2002
 */

import java.util.*;

public class TestRan {
	public static void main(String[] args) {
		final int SIZE = 5;
		double[] a = new double[SIZE];
		Random gen = new Random(42);
		
		// Generate random doubles
		for (int i = 0; i < SIZE; ++i)
			a[i] = gen.nextDouble();
		
		// And print them out
		for (int i = 0; i < SIZE; ++i)
			System.out.println(a[i]);
		
	}
}
