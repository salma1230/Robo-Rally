import java.util.List;

public abstract class Animal{
	// The animals's age.
		protected int age;
		// Whether the animal is alive or not.
		protected boolean alive;
		// The animal's position
		protected Location location;
		
		public abstract int getBreedingAge();
		public abstract int getMaxAge();
		
		public Animal(){
			age = 0;
			alive = true;

		}
		
	protected int getAge() {
		return age;
	}	
	
	protected void setAge(int age) {
		this.age = age;
	}
	
	protected boolean isAlive() {
		return alive;
	}
	
	protected Location getLocation() {
		return location;
	}
	
	protected void setLocation(int row, int col) {
		Location location = new Location(row,col);
		this.location = location;
	}
	
	public abstract void act(Field currentField, Field updatedField,
		List<Animal>newAnimals);
		
	protected void setDead()
	{
		alive = false;
	}
	protected void incrementAge(int MAX_AGE)
	{
		age++;
		if(age > MAX_AGE) {
			alive = false;
		}};
	
	
		public boolean canBreed()
		{
			return age >= getBreedingAge();
		}

		
		
		
		
	}		
	


