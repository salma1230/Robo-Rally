/**
 * Capture a key that failed to match an entry
 * in the address book.
 * 
 * @author David J. Barnes and Michael Kolling.
 * @version 2002.05.14
 */
public class NoMatchingDetailsException extends Exception
{
    /**
	 * 
	 */
	private static final long serialVersionUID = -7815839671150000078L;
	// The key with no match.
    private String key;

    /**
     * Store the details in error.
     * @param key The key with no match.
     */
    public NoMatchingDetailsException(String key)
    {
        this.key = key;
    }

    /**
     * @return The key in error.
     */
    public String getKey()
    {
        return key;
    }
    
    /**
     * @return A diagnostic string containing the key in error.
     */
    public String toString()
    {
        return "No details matching: " + key + " were found.";
    }
}
