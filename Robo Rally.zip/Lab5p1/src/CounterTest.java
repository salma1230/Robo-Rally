import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class CounterTest {
	Counter c1;
	Counter c2;

	@Before
	public void setUp() throws Exception {
		c1 = new Counter("Fox");
		c2 = new Counter("Rabbit");
	}

	@Test
	public void testGetName() {
		assertEquals(c1.getName(), "Fox");
		assertEquals(c2.getName(), "Rabbit");
	}

	@Test
	public void testIncrement() {
		c1.increment();
		assertEquals(c1.getCount(), 1);
		for (int i = 0; i < 10; i++)
			c1.increment();
		assertEquals(c1.getCount(), 11);
	}

	@Test
	public void testReset() {
		assertEquals(c1.getCount(), 0);
		for (int i = 0; i < 10; i++)
			c1.increment();
		c1.reset();
		assertEquals(c1.getCount(), 0);
	}

}
