import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LocationTest {
	Location loc1;
	Location loc2;
	Location loc3 ;
	@Before
	public void setUp() throws Exception {
		 loc1 = new Location(1,3);
		 loc2 = new Location(2,3);
	     loc3 = new Location(1,3);
		
	}

	
	@Test
	 public void testEquality() {
	 assertEquals(loc1, loc3 );
	 assertFalse (loc1.equals(loc2 ));
	}
	@Test
    public void testAccessors(){
		assertEquals(loc1.getRow(), 1);
		assertEquals(loc2.getCol(), 3);
		
	}
	
		 
		 
	 }
	

