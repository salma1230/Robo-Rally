package src;
import static org.junit.Assert.*;

import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;


/**
 * Performs unit tests on the {@link SchoolDirectory} class.
 *
 * @author Ian T. Nabney
 * @version 8 January 2012
 */

public class TestSchoolDirectory {
	private SchoolDirectory dir;
	private Student1[] students = {
			new Student1("Harry Potter"),
			new Student1("Ron Weasley"),
			new Student1("Hermione Grainger"),
			new Student1("Cedric Diggory",   3),
			new Student1("Luna Lovegood"),
			new UpperClassStudents1("Tom Riddle", 7, 'O'),
			new UpperClassStudents1("Fred Weasley", 8, 'E')
	};

	/**
	 * Set up the tests
	 */
	@Before
	public void setUp() {
		dir = new SchoolDirectory();
		for(int i = 0; i < students.length; i++) {
			dir.enrollPupil(students[i]);
		}
	}


	/**
	 * Test the equality method
	 */
	@Test
	public  void testEquals() {
		
	}

	/**
	 * Test the addition and removal of pupils
	 */
	@Test
	public void testPupils() {
		SchoolDirectory d1 = new SchoolDirectory();
		d1.enrollPupil(students[0]);
		assertEquals(d1.toString(), "School directory is\n"+students[0].toString()+"\n");

		assertTrue(d1.removePupil(students[0]));
		assertEquals(d1.toString(), "School directory is\n");

		assertFalse(d1.removePupil(students[0]));

	}
	
	public void testString() {
		SchoolDirectory d1 = new SchoolDirectory();
		for(int i = 0; i<students.length; i++) {
			d1.enrollPupil(students[i]);

		}
	assertEquals(d1.toString(),"School directory is\n"+students[0].toString()+"\n"+students[1].toString()+"\n"+students[2].toString()+"\n"+students[3].toString()+"\n"
		+students[4].toString()+"\n"+students[5].toString()+"\n"+students[6].toString()+"\n" );
	HashSet<Character> test1 = new HashSet<Character>();
	test1.add('O');
	test1.add('E');
	assertEquals(d1.listGrades(), test1);
	
		
		
	}


	

		
		
	}



