package src;

public class UpperClassStudents1 extends Student1 {
private char OWLgrade;
	public UpperClassStudents1(String name, int year, char grade) {
		super(name, year);
		OWLgrade = grade;
		// TODO Auto-generated constructor stub
	}
public char getGrade() {
	
	return OWLgrade;
	
}
	public String toString() {
		return super.toString();
		
		
	}
}
