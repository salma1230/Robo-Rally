package src;
import java.util.*;
import java.util.HashSet;
/**
 * Contains records of students at a school
 *
 * @author Ian T. Nabney
 * @version 0.1 (14 Dec 2004)
 */


public class SchoolDirectory {
	private ArrayList<Student1> directory;

	/**
	 * Create empty directory
	 */
	public SchoolDirectory() {
		directory = new ArrayList<Student1>();
	}

	/**
	 * Enrol a new pupil
	 */
	public void enrollPupil(Student1 student) {
		directory.add(student);
	}

	/**
	 * Remove a pupil from the directory
	 */
	public boolean removePupil(Student1 student) {
		int sIndex = directory.indexOf(student);
		if (sIndex == -1) {
			return false;
		}
		else {
			directory.remove(sIndex);
			return true;
		}
	}

	/**
	 * Create a <code>String</code> representation of the directory
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer("School directory is\n");
		for (Student1 s : directory) {
			sb.append(s.toString());
			sb.append("\n");
		}
		return sb.toString();
	}

	public ArrayList<Student1> searchByKey(String key) {
		ArrayList<Student1> result = new ArrayList<Student1>();
		for (Student1 s : directory) {
			Integer i = new Integer(s.getHUN());
			if (s.getName().startsWith(key) || i.toString().startsWith(key)) {
				result.add(s);
			}
		}

		return result;
	}

	/**
	 * Tests for equality.  Two directories are the same if the
	 * the lists that they contain are the same.
	 */
	public boolean equals(SchoolDirectory d) {
		if (this.directory.equals(d.directory) ) {
			return true;
		}
		else {
			return false;
		}
	}
	public HashSet<Character>listGrades(){
		HashSet<Character> grades = new HashSet<Character>();
		for(Student1 s : directory ) {
			if(s instanceof UpperClassStudents1) {
				UpperClassStudents1 us = (UpperClassStudents1) s;
				grades.add(us.getGrade());
				
			}
			
		}
		return grades;
			
			
			
		}
}





