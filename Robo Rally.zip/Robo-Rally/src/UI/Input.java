package UI;

import java.util.Scanner;

public class Input {
	private Scanner scanner;
	
	public Input(Scanner scanner) {
		scanner = new Scanner(System.in);
		System.out.println("Enter your moves: ");
		int n = scanner.nextLine();
		scanner.close();
	}
}
