package UI;


public class Token {
	
	private Object nextPlayer;
	private boolean token;
	
	public void passToken () {
		
	}
	
	public void nextPlayer () {
		
	}

}
