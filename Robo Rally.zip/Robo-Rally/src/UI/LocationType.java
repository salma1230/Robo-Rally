package UI;

public class LocationType {

	public LocationType () {

	}

	public boolean activated() {
		return false;
	}


}