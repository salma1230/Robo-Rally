package IO;

public class GridIdentityType {

	public GridIdentityType() {
		
	}
	
	public void act() {
		
	}
}
