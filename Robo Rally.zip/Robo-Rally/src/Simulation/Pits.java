package Simulation;


public class Pits {
	
	public boolean hasRobot () {
		return false;
		
	}
	
	public void setRobot () {
		
	}
	
	public void destroyRobot () {
		
	}

}
