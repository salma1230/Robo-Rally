package Simulation;
import java.awt.Robot;

public class Player {

	private Player playerID;
	private Robot robotID;

	public void remove() {

	}

	public Robot getRobotID() {
		return robotID;

	}

	public void setRobotID() {

	}

	public void setPlayerID(Player playerID) {
		this.playerID = playerID;
	}

	public Player getPlayerID() {
		return playerID;

	}

	public boolean hasToken() {
		return false;

	}

	public Player nextPlayer() {
		return playerID;

	}

}
