package Movement;


public class Forward {
	
	private static final Object RobotID = null;
	private char F;
	private boolean complete = true;
	
	public Forward() {
		
	}
	
	public Object getRobotID () {
		return RobotID;
	}
	
	public void passToken () {
		
	}
	
	public boolean actionComplete () {
		return complete;
		
	}
	

}
