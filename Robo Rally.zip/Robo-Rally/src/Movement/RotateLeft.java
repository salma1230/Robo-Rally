package Movement;


public class RotateLeft {
	
	private static final Object RobotID = null;
	private char L;
	private boolean complete = true;
	
	public RotateLeft() {
		
	}
	
	public Object getRobotID () {
		return RobotID;
	}
	
	public void passToken () {
		
	}
	
	public boolean actionComplete () {
		return complete;
		
	}
	

}
