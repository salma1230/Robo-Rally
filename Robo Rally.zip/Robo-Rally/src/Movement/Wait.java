package Movement;


public class Wait {
	
	private static final Object RobotID = null;
	private char W;
	private boolean complete = true;
	
	public Wait() {
		
	}
	
	public Object getRobotID () {
		return RobotID;
	}
	
	public void passToken () {
		
	}
	
	public boolean actionComplete () {
		return complete;
		
	}
	

}
